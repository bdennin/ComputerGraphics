package RayTracer;

public interface Surface {
	public void intersect(Ray ray);
}
